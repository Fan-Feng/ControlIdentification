# Apriori-matlab
This is a simple implementation of Apriori algorithm using matlab

Usage
  [resultItems,resultRules] = apriori(dataset.csv,minSupport.minConfidence)
  
